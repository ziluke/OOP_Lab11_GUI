#include "UndoAction.h"



UndoAction::UndoAction()
{
}


UndoAction::~UndoAction()
{
}
