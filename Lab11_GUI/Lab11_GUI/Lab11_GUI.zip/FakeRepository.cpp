#include "FakeRepository.h"



FakeRepository::FakeRepository()
{
}


FakeRepository::~FakeRepository()
{
}
