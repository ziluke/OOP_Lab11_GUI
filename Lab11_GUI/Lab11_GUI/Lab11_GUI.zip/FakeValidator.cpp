#include "FakeValidator.h"



FakeValidator::FakeValidator()
{
}


FakeValidator::~FakeValidator()
{
}
